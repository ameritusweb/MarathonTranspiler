﻿namespace Server.Attributes
{
    public class AsyncAttribute : System.Attribute
    {
    }
}
