namespace ReactApp1.Server
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
